<?php


// dangvuduc
// trnsl.1.1.20181012T135022Z.40e5478585e9436a.8ad45acb36a17bcead433af1cd57ac50bef15032

function add_submenu_options2()
{
    add_submenu_page(
            'themes.php', // Menu cha
            'Nut test012', // Tiêu đề của menu
            'Nut test012', // Tên của menu
            'edit_pages',//'manage_options',// Vùng truy cập, giá trị này có ý nghĩa chỉ có supper admin và admin đc dùng
            'test-012', // Slug của menu
            'nuttest' // Hàm callback hiển thị nội dung của menu
    );
}

function currentUrl() {
    $protocol = strpos(strtolower($_SERVER['SERVER_PROTOCOL']),'https') === FALSE ? 'http' : 'https';
    $host     = $_SERVER['HTTP_HOST'];
    $script   = $_SERVER['SCRIPT_NAME'];
    $params   = $_SERVER['QUERY_STRING'];

    return $protocol . '://' . $host . $script . '?' . $params;
}

function nuttest() {
if ($_GET['action'] == "edit"){
	include 'trang-edit-baiviet.php';

	} else {
		global $wpdb;
	  	$ketqua = $wpdb->get_results("SELECT * FROM wp_draft order by date desc");
	  	echo '<caption align="top">DANH SÁCH BÀI VIẾT</caption>';

	  	foreach ($ketqua as $key) {
		  	$weblink = explode("/",$key->link);
		  	$weblink = $weblink[2];

		  	echo '<table>
		  		  <tr>
				  	<th align="left"> <a href="'.currentUrl().'&action=edit&myPost=10>'.$key->title.'</a> '.$weblink.'</th>
					<td>'.$key->date.'</td>
				  </tr>
				  <tr>
				  	<td>'.substr($key->content, 0, 400).'...</td>
				  </tr>
				 </table>';
			 }
		}
}

add_action('admin_menu', 'add_submenu_options2');



?>

