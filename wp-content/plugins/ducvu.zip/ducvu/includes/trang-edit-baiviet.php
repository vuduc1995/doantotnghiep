<?php

	global $wpdb;
	// echo 'details of '.$_GET['myPost'].'</br>';
  	$ketqua = $wpdb->get_results("SELECT * FROM wp_draft WHERE link like '%" . $link . "%'");
  	// echo '<br/>';

$bien_soan = $_POST['bien_soan'];
$tieu_de = $_POST['tieu_de'];
$category = $_POST['category'];

if ($bien_soan) {

// $parentId = 47;
// if ($category == 'an toan thong tin') {
// $parentId = 50;0
// }

global $wpdb;
      // Lưu vào CSDL
    $r = rand(5, 15);
    $wpdb->insert( 
      'wp_posts', 
      array(
        'post_author' => '1', 
        'post_content' => $bien_soan,
        'post_name' => 'ok-link-'.$r,
        'post_type' => 'post',
        'post_title'=> $tieu_de,
        'post_status'=> 'publish',
        'post_parent' => $parentId,
        'guid'=> 'abc.com',
        'post_date' => '2018-11-15 13:23:00',
        'post_date_gmt' => '2018-11-15 13:23:00'

        

      ),
      array( 
        '%s', 
        '%s', 
        '%s',
        '%s', 
        '%s',
        '%s',
        '%s',
        '%s',
        '%s',
        '%s'
      ) 
    );

}


?>


<script src="https://storage.googleapis.com/code-snippets/rapidapi.min.js"></script>
<script>
var rapid = new RapidAPI("default-application_5bc0a2f3e4b09cbc25b0ba31", "8235edb8-21be-471b-bcc2-97bc8a96f336");

rapid.call('YandexTranslate', 'translate', { 
  'apiKey': 'trnsl.1.1.20181012T135022Z.40e5478585e9436a.8ad45acb36a17bcead433af1cd57ac50bef15032',
  'lang': 'vi-en',
  // 'text': 'xin chào'

}).on('success', function (payload) {
  console.log(payload);
}).on('error', function (payload) {
  console.log(payload);
});

function trans(type,data) {
rapid.call('YandexTranslate', 'translate', { 
  'apiKey': 'trnsl.1.1.20181012T135022Z.40e5478585e9436a.8ad45acb36a17bcead433af1cd57ac50bef15032',
  'lang': type,
  'text': data

}).on('success', function (payload) {
  console.log(payload);
  document.getElementById('bai_dich').value = payload.text[0];
}).on('error', function (payload) {
  console.log(payload);
});
}
</script>


<div class="wrap">
       <div class="icon32" id="icon-options-general"><br /></div>
       <h1 style="font-size: 20px"> <b> Trang Chỉnh Sửa </b></h1>
       
       <form method="post" action="">
           <table class="form-table">
               <tbody>
                  
                    <tr valign="top">
                       <th scope="row"><label for="stellissimo_text_content">Bài Gốc</label></th>
                           <td>
                               <textarea id="stellissimo_text_content" name="stellissimo_text_content" style="width:500px; height:350px"><?php
                          	foreach ($ketqua as $key) {
                          		if ($key == $_GET['myPost'])
                        	  	echo $key->content;
                        	 }
                               ?></textarea>
                                  
                           </td>
                       <th scope="row"><label for="bien_soan">Tiêu đề</label></th>
                           <td scope="row">
                               <textarea id="tieu_de" name="tieu_de" style="width:500px; height:100px"><?php ; ?></textarea>
                               <!-- <span class="description"><br>Insert here a TEXT or HTML code, this will be show in each pages and posts</span> -->    
                           </td>

                   </tr>
                   <tr valign="top">
                       <th scope="row"></th>
                           <td>
                               <p class="submit">
                                   <!-- <input type="submit" class="button-primary" id="submit" name="submit" value="<?php _e('Save Changes') ?>" /> -->
                                   <input type= "button" class="button-primary" id="abc" name="xyz" value="Translate" 
                                   onclick="trans('vi-en',document.getElementById('stellissimo_text_content').value)"/>
                               </p>
                           </td>
                           <th scope="row"><label for="bien_soan">Biên soạn</label></th>
                           <td rowspan= "3">
                               <textarea id="bien_soan" name="bien_soan" style="width:500px; height:800px"><?php ; ?></textarea>
                               <!-- <span class="description"><br>Insert here a TEXT or HTML code, this will be show in each pages and posts</span> -->    
                           </td>
                   </tr>
                   <tr valign="top">
                       <th scope="row"><label for="stellissimo_text_content">Bài Dịch</label></th>
                           <td>
                               <textarea id="bai_dich" name="stellissimo_text_content" style="width:500px; height:350px"><?php ; ?></textarea>
                               <span class="description"><br>Bài đã dịch</span>    
                           </td>
                   </tr>
                   <tr valign="top">
                       <th scope="row"></th>
                           <td>
                               <p class="submit">
                                   <input type="submit" class="button-primary" id="submit" name="submit" value="<?php _e('Save Changes') ?>" />
                               </p>
                           </td>
                   </tr>
                                
               </tbody>
           </table>
           
       </form>
</div>
