<?php
/**
Plugin Name: Them nut add button
Plugin URI: URL Plugin trên wordpress.org
Description: Mô tả cho plugin
Author: Vu Duc
Version: Version plugin
Author URI: Trang web tác giả
*/

require 'includes/hook-filter.php';
require 'includes/hook-action.php';
require 'includes/options-api.php';