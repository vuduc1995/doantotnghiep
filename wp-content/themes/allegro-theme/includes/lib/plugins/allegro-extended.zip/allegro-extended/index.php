<?php
	/*
	Plugin Name: 	Allegro Extended
	Plugin URI: 	http://www.orange-themes.com/
	Description: 	Allegro shortcodes & galleries
	Version: 		1.0.0
	Author: 		Orange Themes
	Author URI: 	http://www.orange-themes.com/
	Domain Path:    /languages
	Text Domain:	allegro
	License:		GPL-2.0+
	License URI:	http://www.gnu.org/licenses/gpl-2.0.txt
	*/

function allegro_extended() {
	return true;
}

require_once( plugin_dir_path(__FILE__).'shortcodes/init.php' );
add_action('init', 'create_gallery');

if (!defined('OT_POST_GALLERY')) {
	//POST TYPES
	define("OT_POST_GALLERY","gallery");	
}

function create_gallery() {
		
	$labels = array(
    'name' => _x('Gallery', 'allegro menu', 'allegro'),
    'singular_name' => _x('Gallery Menu', 'allegro menu', 'allegro'),
    'add_new' => _x('Add New', 'allegro menu', 'allegro'),
    'add_new_item' => esc_html__('Add New Item','allegro-theme'),
    'edit_item' => esc_html__('Edit Item','allegro-theme'),
    'new_item' => esc_html__('New Gallery Item','allegro-theme'),
    'view_item' => esc_html__('View Item','allegro-theme'),
    'search_items' => esc_html__('Search Gallery Items','allegro-theme'),
    'not_found' =>  esc_html__('No gallery items found','allegro-theme'),
    'not_found_in_trash' => esc_html__('No gallery items found in Trash','allegro-theme'), 
    'parent_item_colon' => ''
	);
  
	register_taxonomy(OT_POST_GALLERY."-cat", 
					    	array("Gallery Categories"), 
					    	array(	"hierarchical" => true, 
					    			"label" => "Gallery Categories", 
					    			"singular_label" => "Gallery Categories", 
					    			"rewrite" => true,
					    			"query_var" => true
					    		));  
		
		register_post_type( OT_POST_GALLERY,
		array( 'labels' => $labels,
	         'public' => true,  
	         'show_ui' => true,  
	         'capability_type' => 'post',  
	         'hierarchical' => false,  
			 'taxonomies' => array(OT_POST_GALLERY.'-cat'),
	         'supports' => array('title', 'editor', 'thumbnail', 'comments', 'page-attributes', 'excerpt') ) );

}