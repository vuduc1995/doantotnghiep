<?php
	add_shortcode('social', 'social_handler');
	

	function social_handler($atts, $content=null, $code="") {
		/* Icon */
		$icon=$atts["icon"];
		$link=$atts["link"];

		switch ($icon) {
			case '62217':
				$name = esc_html__('Twitter','allegro-theme');
				break;
			case '62220':
				$name = esc_html__('Facebook','allegro-theme');
				break;
			case '62223':
				$name = esc_html__('Google+','allegro-theme');
				break;
			case '62226':
				$name = esc_html__('Pinterest','allegro-theme');
				break;
			case '62229':
				$name = esc_html__('Tumbrl','allegro-theme');
				break;
			case '62211':
				$name = esc_html__('Flickr','allegro-theme');
				break;
			case '62214':
				$name = esc_html__('Vimeo','allegro-theme');
				break;
			case '62232':
				$name = esc_html__('LinkedIn','allegro-theme');
				break;
			case '62235':
				$name = esc_html__('Dribbble','allegro-theme');
				break;
			case '62238':
				$name = esc_html__('StumbleUpon','allegro-theme');
				break;
			case '62241':
				$name = esc_html__('LastFM','allegro-theme');
				break;
			case '62244':
				$name = esc_html__('Rdio','allegro-theme');
				break;
			case '62247':
				$name = esc_html__('Spotify','allegro-theme');
				break;
			case '62253':
				$name = esc_html__('Instagram','allegro-theme');
				break;
			case '62280':
				$name = esc_html__('Soundcloud','allegro-theme');
				break;
			case '62286':
				$name = esc_html__('Behance','allegro-theme');
				break;
			
			default:
				$name = false;
				break;
		}
		$content = '<a href="'.$link.'" target="_blank" class="social-icon">
						<span class="icon-text">&#'.$icon.';</span>
						<b>'.$name.'</b>
						<i>'.esc_html__("Follow us",'allegro-theme').'</i>
					</a>';
		return $content;
	}
	
?>